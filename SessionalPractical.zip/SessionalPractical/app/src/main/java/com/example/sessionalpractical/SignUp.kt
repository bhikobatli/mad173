package com.example.sessionalpractical

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_sign_up.*

class SignUp : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        signup2.setOnClickListener {
            if(useridsignup.text.toString() == "" || passwordsignup.text.toString() == "" || passwordsignup2.text.toString() == "")
            {
                var toast = Toast.makeText(this,"Enter UserId, Password and Re-Enter Password", Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.TOP,0,300)
                toast.show()
                useridsignup.setText("")
                passwordsignup.setText("")
                passwordsignup2.setText("")
                useridsignup.requestFocus()
            }
            else if(passwordsignup.text.toString() != passwordsignup2.text.toString())
           {

                    var toast = Toast.makeText(this,"Passwords Must be Same...", Toast.LENGTH_SHORT)
                    toast.setGravity(Gravity.TOP,0,300)
                    toast.show()
                    passwordsignup.setText("")
                    passwordsignup2.setText("")
                    passwordsignup.requestFocus()

                }
                else
                {
                    var splogin = getSharedPreferences("splogin", Context.MODE_PRIVATE)
                    var edt = splogin.edit()
                    edt.apply{
                        putString("uid",useridsignup.text.toString())
                        putString("pwd",passwordsignup.text.toString())
                    }.apply()
                    var toast = Toast.makeText(this,"User Created Successfully.....",Toast.LENGTH_SHORT)
                    toast.setGravity(Gravity.TOP,0,300)

                    toast.show()
                    startActivity(Intent(this, Login::class.java))

                }
            }





        }

    }
