package com.example.sessionalpractical

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class CustomAdapter(
    var myFriends: MyFriends,
    var names: Array<String>,
    var photos: Array<Int>
):BaseAdapter() {
    override fun getCount(): Int {
       return names.size
    }

    override fun getItem(p0: Int): Any {
        return p0
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var inview = LayoutInflater.from(myFriends).inflate(R.layout.friendslist,p2, false)
        var nm = inview.findViewById<TextView>(R.id.name)
        var pt = inview.findViewById<ImageView>(R.id.photo)
            nm.text = names[p0]
            pt.setImageResource(photos[p0])
        return inview
    }

}
