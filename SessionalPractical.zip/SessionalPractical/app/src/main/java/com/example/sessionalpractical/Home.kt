package com.example.sessionalpractical

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import kotlinx.android.synthetic.main.activity_home.*

class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    friendsbtn.setOnClickListener {
        startActivity(Intent(this,MyFriends::class.java))

    }
        logoutbtn.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menu?.add(1,101,1,"FRIENDS")
        menu?.add(1,102,2,"LOGOUT")
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            101 -> startActivity(Intent(this,MyFriends::class.java))
            102 -> startActivity(Intent(this, Login::class.java))
        }

        return super.onOptionsItemSelected(item)
    }

}