package com.example.sessionalpractical

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import kotlinx.android.synthetic.main.activity_my_friends.*

class MyFriends : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_friends)
        var names = arrayOf("Hiral","Aayushi","Jhon","Virat","Hardy")
        var photos = arrayOf(R.drawable.pass1, R.drawable.pass2,R.drawable.pass3,R.drawable.pass4,R.drawable.pass5)

       var myadapter = CustomAdapter(this,names,photos)
        listview.adapter = myadapter

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menu?.add(1,101,1,"HOME")
        menu?.add(1,102,2,"Logout")
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            101-> startActivity(Intent(this, Home::class.java ))
            102-> startActivity(Intent(this, Login::class.java ))
        }
        return super.onOptionsItemSelected(item)
    }
}