package com.example.sessionalpractical

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*

class Login : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        var splogin = getSharedPreferences("splogin", Context.MODE_PRIVATE)

        var id= splogin.getString("uid",null)
        var pw= splogin.getString("pwd",null)
        login.setOnClickListener {

            if(userid.text.toString() =="" || password.text.toString() == "")
            {
                var toast = Toast.makeText(this,"Enter UserId and Password Both",Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.TOP,0,300)
                toast.show()
                userid.requestFocus()
            }
            else if(userid.text.toString() == id && password.text.toString() == pw)
            {
                startActivity(Intent(this, Home::class.java))
            }
            else
            {
                var toast = Toast.makeText(this,"Enter Correct Credentials to Login",Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.TOP,0,300)
                toast.show()
                userid.setText("")
                password.setText("")
                userid.requestFocus()
            }


        }
        signup.setOnClickListener {
            startActivity(Intent(this, SignUp::class.java))

        }
    }
}